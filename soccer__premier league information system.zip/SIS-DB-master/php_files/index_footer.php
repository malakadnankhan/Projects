<!-- <!DOCTYPE html> -->
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/my_css.css">
</head>
<body>


    <!-- FOOTER START-->
    <footer style="background: #37003c">
        <div class="row align-center copyright">
            <div class="col-sm-12" align="center" style="color:whitesmoke">
                <br>
                <h3>&copy;PREMIER LEAGUE 2019</h3>
                <p><img src="images/footer.png" id ="img_footer"></span></p>
            </div>
        </div>
    </footer>
    <!-- FOOTER END-->
    

    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>