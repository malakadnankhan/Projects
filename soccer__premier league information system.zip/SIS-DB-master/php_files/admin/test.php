<?php include "admin_header.php" ?>

<!DOCTYPE html>
<html>
<head>    
    <title> Hello </title>
</head>
<body>
    <h1> HELLO </h1>
</body>
</html>

<?php include "admin_footer.php"; ?>
