SYSTEMTIME struct
	wYear WORD ?			; year (4 digits)
	wMonth WORD ?			; month (1-12)
	wDayOfWeek WORD ?		; day of week (0-6)
	wDay WORD ?			; day (1-31)  The day of the month. The valid values for this member are 1 through 31
	wHour WORD ?			; hours (0-23)
	wMinute WORD ?			; minutes (0-59)
	wSecond WORD ?			; seconds (0-59)
	wMilliseconds WORD ?	; milliseconds (0-999)
SYSTEMTIME ENDS
			;;//////////// Data segemntn,defining Data Variables


.data
sysTime SYSTEMTIME <>

 remindDate word 0 
 remindMonth word 0
 remindYear word 0
 isReminder byte 0       ;node			;(0/1 only two values)
 reminderMsg byte 20 dup(?)

 newDate  word ?
 newMonth word ?
 newYear  word ?

startTime DWORD ?
timeElasped DWORD ?
countDays word 0
index word 0

PMonth word ?
PYear word ?
PDate word ?

showMonth WORD ?
showYear WORD ?

IsLeap byte 0
M30or31 word ?
DayOf1 byte ?
divisor word ?
monthCheck2 WORD 4,6,9,11

DAYS byte  'SUN ','MON ' ,'TUE ' ,'WED ' ,'THU ' ,'FRI ' ,'SAT ',0

MonthInteger byte 1,2,3,4,5,6,7,8,9,10,11,12
MONTHS	byte 'JAN' ,'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',0

		